package com.day7;

public class MultiThread extends Thread{

    String task;

    public MultiThread(String task) {
        this.task = task;
    }

    @Override
    public void run() {
        for(int i = 0; i<=8;i++){
            System.out.println(task+" : " + i);
            try {
                Thread.sleep(1000);
            }catch (InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        MultiThread multiThread = new MultiThread("Cut the ticket");

        MultiThread multiThread1 = new MultiThread("Show your seat number");

        Thread thread = new Thread(multiThread);
        Thread thread1 = new Thread(multiThread1);

        thread.start();
        thread1.start();
    }
}
