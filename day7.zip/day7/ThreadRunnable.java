package com.day7;

public class ThreadRunnable implements Runnable{
    @Override
    public void run() {
        System.out.println("New Thread Running");
        for(int i = 1; i<=5;i++){
            System.out.println(i);
        }
        System.out.println(Thread.currentThread());
    }

    public static void main(String[] args) {
        System.out.println("Main thread is running");

        //Create an obj of thread class
        ThreadRunnable th = new ThreadRunnable();

        Thread t = new Thread(th);

        t.start();
    }
}
