package com.day7;

public class X {
    void display1(X obj2){
        System.out.println("Thread1 is waiting for Thread2 to release the lock");
        synchronized (obj2) {
            System.out.println("DeadLock Occurred");
        }
    }

    void display2(X obj1){
        System.out.println("Thread2 is waiting for Thread1 to release the lock");
        synchronized (obj1){
            System.out.println("DeadLock Occurred");
        }
    }
}
