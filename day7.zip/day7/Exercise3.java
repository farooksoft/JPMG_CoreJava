package com.day7;
//Program to set priorities of thread
public class Exercise3 extends Thread{
    @Override
    public void run() {
        System.out.println("Run Method");
        String threadName = Thread.currentThread().getName();
        Integer threadPrio = Thread.currentThread().getPriority();
        System.out.println(threadName + " , " + threadPrio);
    }

    public static void main(String[] args) {
        Exercise3 exercise3 = new Exercise3();
        Exercise3 exercise31 = new Exercise3();
        Exercise3 exercise32 = new Exercise3();

        exercise3.setPriority(Thread.MAX_PRIORITY);
        exercise31.setPriority(Thread.MIN_PRIORITY);
        exercise32.setPriority(Thread.NORM_PRIORITY);

        exercise3.start();
        exercise31.start();
        exercise32.start();
    }
}
