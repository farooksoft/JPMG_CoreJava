package com.day7;

public class MultiTaskingThread implements Runnable{
    int a = 20, b =10;
    @Override
    public void run() {
        addition(); //task 1
        subtraction(); //task 2
        multiplication(); //task 3
    }

    private void addition() {
        int sum = a+b;
        System.out.println("Addition of 2 nos:" +sum);
    }

    private void subtraction() {
        int sub = a-b;
        System.out.println("Subtraction of 2 nos: "+sub);
    }

    public void multiplication(){
        int mult = a*b;
        System.out.println("Multiplication of 2 nos: " +mult);
    }
// class MyThread extends AnotherClass implements Runnable
    public static void main(String[] args) {
        System.out.println("Main thread running");

        MultiTaskingThread multiTaskingThread = new MultiTaskingThread();
        Thread thread = new Thread(multiTaskingThread);
        thread.start();
    }

}
