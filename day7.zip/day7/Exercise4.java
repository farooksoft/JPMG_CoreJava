package com.day7;
//Program to display all running thread
public class Exercise4 extends Thread{
    public static void main(String[] args) {
        System.out.println("Main Method");

        Exercise4 obj = new Exercise4();
        obj.setName("\n Thread Name");
        obj.start();

        ThreadGroup currentGroup = Thread.currentThread().getThreadGroup();
        int numthreads = currentGroup.activeCount();
        Thread[] isThread = new Thread[numthreads];
        currentGroup.enumerate(isThread);

        for(int i = 1; i<numthreads ; i++){
            System.out.println("Number of threads:" + i + " "+ isThread[i].getName());
        }
        Thread currentThread = Thread.currentThread();
        System.out.println("Current Thread running: " + currentThread);
    }
}
