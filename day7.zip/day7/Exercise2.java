package com.day7;
//Program to creating multiple thread
public class Exercise2 extends Thread{
    private Thread thread;
    private String threadName;

    Exercise2(String msg){
        threadName = msg;
        System.out.println("Creating the thread:" + threadName);
    }

    @Override
    public void run() {
        System.out.println("Running thread:" +threadName);
        try {
            for(int i = 0; i<5; i++){
                System.out.println("Thread: "+threadName + " , " + i);
                Thread.sleep(500);
            }
        }catch (InterruptedException ie){
            System.out.println("Exception in Thread:" + threadName);
        }
        System.out.println("Thread" + threadName + " continue...");
    }

    @Override
    public synchronized void start() {
        System.out.println("Start the Method:" + threadName);
        if(threadName == null){
            thread = new Thread(this, threadName);
            thread.start();
        }
    }
}

