package com.day7;

public class MainThread {
    public static void main(String[] args) {
        Thread obj = Thread.currentThread();

        System.out.println("Current Thread: " +obj);
        System.out.println("Name of current Thread: "+obj.getName());
    }
}
