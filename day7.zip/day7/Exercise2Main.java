package com.day7;

public class Exercise2Main {
    public static void main(String[] args) {
        Exercise2 exercise2 = new Exercise2("First Thread");
        exercise2.start();

        Exercise2 exercise21 = new Exercise2("Second Thread");
        exercise21.start();
    }
}
