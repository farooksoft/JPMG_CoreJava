package com.day7;
//Program for Synchronization block
public class Exercise5 {
    void printNumber(int n){
        synchronized (this){
            System.out.println("Table of" + n);
            System.out.println("==============");
            for(int i=1;i<=10;i++){
                System.out.println(n + " * " + i+ " = " +(n*i));
                try{
                    Thread.sleep(1000);
                }catch (InterruptedException ie){
                    System.out.println(ie.getMessage());
                }
            }
        }
    }
}

class Exercise5Main extends Thread{
    Exercise5 exercise5;

    public Exercise5Main(Exercise5 exercise5) {
        this.exercise5 = exercise5;
    }

    @Override
    public void run() {
        exercise5.printNumber(5);
    }
}

class SyncBlock{
    public static void main(String[] args) {
        Exercise5 exercise5 = new Exercise5();
        Exercise5Main exercise5Main = new Exercise5Main(exercise5);
        exercise5Main.start();

    }
}