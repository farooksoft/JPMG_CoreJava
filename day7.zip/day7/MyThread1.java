package com.day7;

public class MyThread1  implements Runnable{
    @Override
    public void run() {
        for(int i=0;i<5;i++){
            System.out.println("First Child Thread: "+i);
        }
        System.out.println("\nFirst Child Thread exited");
    }
}
