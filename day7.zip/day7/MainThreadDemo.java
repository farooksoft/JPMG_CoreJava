package com.day7;

public class MainThreadDemo {
    public static void main(String[] args) {
        //Create the thread obj by calling CurrentThread() of the class Thread
        Thread obj = Thread.currentThread();

        System.out.println("Current thread: "+obj);
        System.out.println("Name of the current Thread is: "+obj.getName());

        obj.setName("New Thread"); // change the name of main thread
        System.out.println("Name of current thread: "+obj);
        System.out.println("Main Thread Existing");
    }
}
