package com.day7;

public class Thread1 extends Thread{
    Table table;

    Thread1(Table table){
        this.table = table;
    }

    @Override
    public void run() {
        table.printTable(2);
    }
}
