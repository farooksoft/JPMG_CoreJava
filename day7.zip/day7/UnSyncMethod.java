package com.day7;

public class UnSyncMethod {
    public static void main(String[] args) {
        Table table = new Table();
        Table table1 = new Table();
        Thread1 thread1 = new Thread1(table);
        Thread2 thread2 = new Thread2(table1);
        thread1.start();
        thread2.start();
    }
}
