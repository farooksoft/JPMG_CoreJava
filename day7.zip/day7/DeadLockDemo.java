package com.day7;

public class DeadLockDemo {
    public static void main(String[] args) {
        X obj1 = new X();
        X obj2 = new X();

        DeadLockThread1 thread1 = new DeadLockThread1(obj1,obj2);
        DeadLockThread2 thread2 = new DeadLockThread2(obj1, obj2);

        thread1.start();
        thread2.start();
    }
}
