package com.day7;

public class Table {
     synchronized void printTable(int n){ //here the method is not sync
        for (int i=1; i<=5; i++){
            System.out.println(n*i);
            try {
                Thread.sleep(2000);
            }catch (InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
    }

    synchronized void printTable1(int n){
        for (int i=1; i<=5; i++){
            System.out.println(n*i);
            try {
                Thread.sleep(2000);
            }catch (InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }

    }
}


