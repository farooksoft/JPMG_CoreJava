package com.day7;

public class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("New Thread is running!!!");
    }

    public static void main(String[] args) {
        System.out.println("Main thread is running");
        //created obj of MyThread
        MyThread myThread = new MyThread();
        //Created the obj of Thread class and pass the obj reference of MyThread
        Thread thread = new Thread(myThread);

        //to run the thread
        thread.start();
    }
}
