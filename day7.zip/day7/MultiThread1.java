package com.day7;

public class MultiThread1 {
    public static void main(String[] args) {
        MyThread1 myThread1 = new MyThread1();
        Thread thread = new Thread(myThread1);
        thread.start(); //1st Thread Execution

        MyThread2 myThread2 = new MyThread2();
        Thread thread1 = new Thread(myThread2);
        thread1.start(); //2nd thread execution

        int j = 0;
        while (j<4){
            System.out.println("Main thread: "+j);
            j = j+1;
        }
        System.out.println("\tMain thread Running");
    }
}
