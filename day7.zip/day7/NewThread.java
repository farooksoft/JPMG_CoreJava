package com.day7;

public class NewThread extends Thread {
    @Override
    public void run() {
        Thread th1 = Thread.currentThread();
        System.out.println(th1);
        System.out.println("New Thread starts running");
        System.out.println("in in run() method");
    }

    public static void main(String[] args) {
        System.out.println("Main thread starts running");

        Thread ct1 = Thread.currentThread();
        System.out.println(ct1);

        int ac1 = Thread.activeCount();
        System.out.println(ac1);

        //create an object of new thread class
        NewThread newThread = new NewThread();
        int ac2 = Thread.activeCount();
        System.out.println(ac2);

        //create an object of Thread class and pass the obj reference variable
        Thread t = new Thread(newThread);
        int ac3 = Thread.activeCount();
        System.out.println(ac3);

        //now run the thread on the object, for this call start()

        t.start();
        int ac4 = Thread.activeCount();
        System.out.println(ac4);
        t.setName("New Thread");//setting the name of Thread
    }
}
