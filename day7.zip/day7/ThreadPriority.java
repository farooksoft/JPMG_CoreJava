package com.day7;

public class ThreadPriority  implements Runnable {
    @Override
    public void run() {
        System.out.println(Thread.currentThread());
    }

    public static void main(String[] args) {
        ThreadPriority threadPriority = new ThreadPriority();
        Thread thread = new Thread(threadPriority,"First Thread");
        Thread thread1 = new Thread(threadPriority, "Second Thread");
        Thread thread2 = new Thread(threadPriority, "Third Thread");

        thread.setPriority(2);
        thread1.setPriority(4);
        thread2.setPriority(8);

        System.out.println("Priority of Thread:" +thread.getPriority());
        System.out.println("Name of the Thread:" +thread.getName());
        thread.start();
        thread1.start();
        thread2.start();

    }
}
