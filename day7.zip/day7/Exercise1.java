package com.day7;
//Program to implement thread using runnable interface
public class Exercise1 implements Runnable{
    String message;

    public Exercise1(String message) {
        this.message = message;
    }

    @Override
    public void run() {
        for(int count = 0;count<=5;count++){
            try {
                System.out.println("Run method: " +message);
                Thread.sleep(1000);
            }catch (InterruptedException ie){
                System.out.println(ie.getMessage());
            }
        }
    }
}
