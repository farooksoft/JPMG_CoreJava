package com.day3;

import java.util.Arrays;

public class FillArrayDemo {
    public static void main(String[] args) {
        int myArray1[] = new int[5];
        int fillValue = 15;

        Arrays.fill(myArray1,fillValue);

        System.out.println("integer array on filling:"+ Arrays.toString(myArray1));
    }
}
