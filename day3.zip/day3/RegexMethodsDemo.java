package com.day3;

public class RegexMethodsDemo {
    public static void main(String[] args) {
        String text = " one two three two one two five";
        boolean matches = text.matches(".*two.*");
        System.out.println(matches);

        //split()
        String[] twos = text.split("two");
        for(String a : twos)
            System.out.println(a);

        //replaceFirst()
        String s = text.replaceFirst("two", "2");
        System.out.println(s);

        //replaceAll()
        String s1 = text.replaceAll("two", "2");
        System.out.println(s1);


    }
}
