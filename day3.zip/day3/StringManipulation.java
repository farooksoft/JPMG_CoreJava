package com.day3;

public class StringManipulation {
    public static void main(String[] args) {
        String s = "    The Quick Brown fox jumps over a lazy dog    ";
        System.out.println(s);
        System.out.println("Length:" +s.length());
        System.out.println("Char at 15:" +s.charAt(15));
        System.out.println("Sub String with Single index 5:" + s.substring(5));
        System.out.println("Sub string with index (10, 20)"+s.substring(10,20));

        String s1 = "Lazy", s2 = "LAZY";
        System.out.println("Concat s1.concat(s2)" + s1.concat(s2));
        System.out.println("index of (o)"+s.indexOf("o"));
        System.out.println("Equals s1 & s2: "+ s1.equals(s2));
        System.out.println("Equals ignore case" + s1.equalsIgnoreCase(s2));
        System.out.println("Compare to:" + s1.compareTo(s2));
        System.out.println("Compare to ignore case:"+ s1.compareToIgnoreCase(s2));
        System.out.println("Upper case:" + s.toUpperCase());
        System.out.println("lower case:" + s.toLowerCase());
        System.out.println("Trim the data:" + s.trim());

    }
}
