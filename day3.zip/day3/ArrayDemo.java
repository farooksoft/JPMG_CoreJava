package com.day3;

public class ArrayDemo {
    public static void main(String[] args) {
        int[] marks; // declared the array
        marks = new int[5]; // allocated the memory
        //initialized the elements
        marks[0] = 87;
        marks[1] = 65;
        marks[2] = 88;
        marks[3] = 99;
        marks[4] = 67;
        //access the elements of the array
        for (int iterator = 0; iterator< marks.length; iterator++)
            System.out.println("Marks of the students:" + (iterator +1) + ":" +marks[iterator]);

        //for each loop
        for(int itr : marks)
            System.out.println("Marks of the students:" + itr);
    }
}
