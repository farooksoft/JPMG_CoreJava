package com.day3;

import java.util.regex.Pattern;

public class PatternDemo {
    public static void main(String[] args) {
        String text = "This is to search the text with the occurances of http:// pattern.";

        //String regex = ".*http://.*";
        String regex = ".*patt*";

        boolean matches = Pattern.matches(regex, text);
        System.out.println("Matches: "+ matches);
    }
}
