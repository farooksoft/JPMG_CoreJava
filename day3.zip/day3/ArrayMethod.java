package com.day3;

public class ArrayMethod {
    public static void main(String[] args) {
        int myArray[] = {1,2,3,4,5,6,7,8};

        System.out.println("Array before passing to a method");
        for(int i =0; i< myArray.length;i++){
            System.out.println(myArray[i]);
        }

        System.out.println("Array after passing to a method");
        manipulateArray(myArray);
        display(myArray);

    }

    private static void manipulateArray(int[] a) {
        for(int i = 0; i<a.length; i++){
            a[i] = a[i]*10;
        }
    }

    private static void display(int[] a) {
        for(int i = 0; i<a.length; i++){
            System.out.println(a[i]);
        }
    }
}
