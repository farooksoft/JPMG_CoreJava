package com.day3;

public class MultiDimensionalArray {
    public static void main(String[] args) {
        int [][] myArray = new int[3][3];
        myArray[0][0] = 1;
        myArray[0][1] = 2;
        myArray[0][2] = 3;
        myArray[1][0] = 4;
        myArray[1][1] = 5;
        myArray[1][2] = 6;

        for (int i=0; i<3; i++){
            for (int j =0; j<3; j++){
                System.out.println(myArray[i][j]+ " ");
            }
            System.out.println();
        }
    }
}
