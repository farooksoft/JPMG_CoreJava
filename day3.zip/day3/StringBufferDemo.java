package com.day3;

public class StringBufferDemo {
    public static void main(String[] args) {

        StringBuffer sb = new StringBuffer("Harry");
        System.out.println(sb);

        //modify the object
        sb.append("Potter");
        System.out.println(sb);

        //demo 2
        String str = "Harry";
        str.concat("Potter");
        System.out.println(str);

        // String buffer manipulation
        StringBuffer stringBuffer = new StringBuffer("Hello World");
        //insert()
        stringBuffer.insert(2, 123);
        System.out.println("Insert:" +stringBuffer);

        //reverse()
        stringBuffer.reverse();
        System.out.println("Reverse:" +stringBuffer);

        //replace
        stringBuffer.replace(6, 11, "Java");
        System.out.println("replace:" +stringBuffer);

        //capacity
        System.out.println("capacity:" +stringBuffer.capacity());

        //ensure Capacity
        stringBuffer.ensureCapacity(30);
        System.out.println("Insert:" +stringBuffer.capacity()); // (oldcapacity * 2) + 2
    }
}
