package com.day3;

public class StringDemo {
    public static void main(String[] args) {
        String data = new String("Hello World");
        String data1 = "String Literal";

        data = data.concat(" Example");
        System.out.println(data);
        System.out.println(data+ " " + data1);
    }
}
