package com.day3;

import java.util.Arrays;

public class EqualsMethod {
    public static void main(String[] args) {
        int myArray1[] = {10,20, 30};
        int myArray2[] = {10,20, 30};

        System.out.println(" Comparing 2 arrays: "+Arrays.equals(myArray1,myArray2));

        Object[] arr1 = {myArray1};
        Object[] arr2 = {myArray2};
        System.out.println(" Comparing 2 arrays: "+Arrays.deepEquals(arr1,arr2));
    }
}
