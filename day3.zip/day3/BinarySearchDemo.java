package com.day3;

import java.util.Arrays;

public class BinarySearchDemo {
    public static void main(String[] args) {
        int array1[] = {20, 34, 56, 78, 97};
        int intkey = 56;

        System.out.println(intkey + "Found at index"+ Arrays.binarySearch(array1,intkey));
        System.out.println(78 + "Found at index"+ Arrays.binarySearch(array1,78));
    }
}
