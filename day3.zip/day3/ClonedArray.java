package com.day3;

public class ClonedArray {
    public static void main(String[] args) {
        int intArray[][] = {{1,2,3}, {4,5,6}};
        int clonedArray[][] = intArray.clone();
        // prints false
        System.out.println(intArray == clonedArray);

        //it will print true as a shallow copy is created and sub arrays are shared
        System.out.println(intArray[0] == clonedArray[0]);
        System.out.println(intArray[1] == clonedArray[1]);

        for(int i=0; i<2; i++){
            for(int j=0; j<3; j++){
                System.out.println(clonedArray[i][j] + " ");
            }
        }
    }
}
