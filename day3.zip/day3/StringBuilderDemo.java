package com.day3;

public class StringBuilderDemo {
    public static void main(String[] args) {
        StringBuilder s = new StringBuilder("Hello");
        System.out.println(s);

        s.append("World");
        System.out.println(s);

        StringBuffer stringBuffer = new StringBuffer("Hello");
        stringBuffer.append("World");
        System.out.println(stringBuffer);
    }
}
