package com.day3;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatcherDemo {
    public static void main(String[] args) {
        String text = "this is the text which is to be searched for the occurrences of the word 'is'.";

        String regex = "is";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        int count = 0;
        while(matcher.find()){
            count++;
            System.out.println("Found:" +count + ":" + matcher.start() + " " + matcher.end());
        }
    }
}
