package com.day3;

import java.util.Arrays;

public class CopyOfArray {
    public static void main(String[] args) {
        int array1[] = {65,20,34,56,78,97};
        System.out.println("Original");
        System.out.println(Arrays.toString(array1));
        System.out.println("New Array with CopyOf mtd");
        System.out.println(Arrays.toString(Arrays.copyOf(array1,10)));
    }
}
