package com.day3;

public class StringCompare {
    public static void main(String[] args) {
        String s1 = "Hello World";
        String s2 = "HELLO WORLD";
        String s3 = new String("Hello World");
        // checks for the content not the obj ref
        System.out.println(s1.equals(s2));
        System.out.println(s1.equals(s3));
        System.out.println(s1.equalsIgnoreCase(s2));

        // obj ref not the content
        System.out.println(s1 ==s2);
        System.out.println(s1 ==s3);
        System.out.println(s1 ==s1);

        // compares data with uni code value
        System.out.println(s1.compareTo(s2));
        System.out.println(s1.compareTo(s3));

        System.out.println(s1.compareToIgnoreCase(s2));
        System.out.println(s1.compareToIgnoreCase(s3));
    }
}
