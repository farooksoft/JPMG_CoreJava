package com.day3;

public class SingleDimensionalArray {
    public static void main(String[] args) {
        int myArray[] = {50, 60, 70};
        int clonedArray[] = myArray.clone();
        //original array
        for(int i= 0; i< myArray.length; i++){
            System.out.println(myArray[i] + " ");
        }
        // will print false as a deep copy is created for 1D array
        System.out.println(myArray == clonedArray);
        System.out.println("myArray == clonedArray");
        for(int i= 0; i< clonedArray.length; i++){
            System.out.println(clonedArray[i] + " ");
        }
    }
}

