package com.jpmg.demo;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class LoggerDemo {
    public static Logger log = Logger.getLogger(LoggerDemo.class);
    public static void main(String[] args) {
        BasicConfigurator.configure();
        log.setLevel(Level.WARN);
        log.info("Hello world");
        log.error("This is an error message");
        log.warn("This is the warning message");
        log.debug("debug info");
        log.trace("Trace the data");
        log.fatal("Fatal Message");

    }
}
