package com.day2;

class Grandfather{
    int a ;
    Grandfather(){
        System.out.println("Iam the Grandfather");
    }
}
class Father extends Grandfather{
    Father(){
        System.out.println("Im the Father and inherit the properties of Grandfather");
    }
}
public class Son extends Father{
    Son(){
        System.out.println("Im the Son and inherit the properties of Father");
    }
    public static void main(String args[]){
        Son son = new Son();
        son.a = 34;
    }
}
