package com.day2;

class FatherOverriding{
    void shoot(){
        System.out.println("Im Father im right handed");
    }
}
public class ChildOverriding extends FatherOverriding {
    void shoot(){
        System.out.println("Im Son im Left handed");
    }
    public static void main(String args[]){
        FatherOverriding fatherOverriding = new FatherOverriding();
        fatherOverriding.shoot();

        //ChildOverriding fc = new ChildOverriding();
        FatherOverriding fc = new ChildOverriding();
        fc.shoot(); //this is dynamic method dispatch. The compiler decides method call at runtime
    }
}
