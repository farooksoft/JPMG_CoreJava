package com.day2;

class Animal{
    final void characteristics(){
        int legs = 4;
        int eyes = 2;

        System.out.println(legs);
        System.out.println(eyes);
    }

}
public class FinalMethod extends Animal{
    final void sound(){
        System.out.println("additional Characteristics");
    }
    public static void main(String args[]){
        FinalMethod finalMethod = new FinalMethod();
        finalMethod.sound();
        finalMethod.characteristics();
    }
}
