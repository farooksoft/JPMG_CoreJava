package com.day2;

public class EmployeeDetails {
    final int id; //blank final variable
    EmployeeDetails(int idNum){
        id = idNum;
    }

    void getDetails(){
        System.out.println("emp Id " + id);
    }
    public static void main(String args[]){
        EmployeeDetails employeeDetails = new EmployeeDetails(706176);
        employeeDetails.getDetails();
    }

}
