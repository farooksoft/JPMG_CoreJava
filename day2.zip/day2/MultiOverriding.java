package com.day2;
class Gfather{
    void move(){
        System.out.println("I use my stick to move");
    }
}
class Father2 extends Gfather{
    void move(){
        System.out.println("I can walk fast");
    }
}
class Baby extends Father2{
    void move(){
        System.out.println("I crawl and have fun!!!");
    }
}
public class MultiOverriding {
    public static void main(String args[]){
        Gfather gfather = new Father2();
//        Gfather gfather1 = new Baby();
//        Gfather gfather2 = new Gfather();
        gfather.move();
        //gfather1.move();
    }
}
