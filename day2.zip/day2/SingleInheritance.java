package com.day2;

class A{ //parent class
    int a,b;
    void display(){
        System.out.println("Inside the class A values" +a + " " + b);
    }
}
class B extends A{
    int c;
    void show(){
        System.out.println("Inside the class B values" +a + " " + b + " " + c);
    }
}

public class SingleInheritance {
    public static void main(String args[]){
        B obj = new B();
        obj.a = 12;
        obj.b = 50;
        obj.c = 30;
        obj.display();
        obj.show();
    }
}
