package com.day2;

class Father1{
    String familyName;
    String houseAddress;
    Father1(){
        familyName = "Programmer";
        houseAddress = "Mumbai";
    }
}
class Son1 extends Father1{
    Son1(){
        System.out.println("Iam the Son");
        System.out.println("My family name is " + this.familyName + " iam from " + this.houseAddress);
    }
}
class Daughter extends Father1{
    Daughter(){
        System.out.println("Iam the Daughter");
        System.out.println("My family name is " + this.familyName + " iam from " + this.houseAddress);
    }
}
class Daughter1 extends Father1{
    Daughter1(){
        System.out.println("Iam the Daughter1");
        System.out.println("My family name is " + this.familyName + " iam from " + this.houseAddress);
    }
}
public class HierarchicalInheritanceDemo {
    public static void main(String args[]){
        Son1 son1 = new Son1();
        Daughter daughter = new Daughter();
        Daughter1 daughter1 = new Daughter1();
    }
}
//    Iam the Son
//        My family name is Programmer iam from Mumbai
//        Iam the Daughter
//        My family name is Programmer iam from Mumbai
