package com.day2;

public class FinalReferenceVariable {
    public static void main(String args[]){
        //declaring the final reference variable
        final StringBuilder builder = new StringBuilder("Hello");
        System.out.println(builder);

        //changing the internal state of the object reference by final reference variable builder
        builder.append("World");
        System.out.println(builder);
    }
}
