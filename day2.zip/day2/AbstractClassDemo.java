package com.day2;

import java.util.Scanner;

abstract class Shape{
 Shape(){
        System.out.println("Abstract Class Demo");
    }
    int len, bre, rad;
    Scanner input = new Scanner(System.in);
    abstract void printArea();
}

class Rectangle1 extends Shape{
Rectangle1(){    super();}
    @Override
    void printArea() {
        //len = 20;
        //bre = 10;
        len = input.nextInt();
        bre = input.nextInt();
        System.out.println(len*bre);
    }
}
class Circle extends Shape{

    @Override
    void printArea() {
        rad = 5;
        System.out.println(3.14f*rad*rad);
    }
}
public class AbstractClassDemo {
    public static void main(String args[]){
        Rectangle1 rectangle1 = new Rectangle1();
        rectangle1.printArea();

        Circle circle = new Circle();
        circle.printArea();
    }
}
