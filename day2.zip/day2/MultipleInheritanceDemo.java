package com.day2;

interface Moveable{
    public void run();
}
interface Speakable{
    public void speak();
}
interface Ability extends Moveable,Speakable{
    public void show();
}

class Person implements Ability{

    @Override
    public void run() {
        System.out.println("running");
    }

    @Override
    public void speak() {
        System.out.println("Speaking");
    }

    @Override
    public void show() {
        System.out.println("Displaying");
    }
}
public class MultipleInheritanceDemo {
    public static void main(String args[]){
        Person person = new Person();
        Ability ability = new Person();
        person.run();
        person.show();
        person.speak();
        ability.show();

    }
}
