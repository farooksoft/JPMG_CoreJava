package com.day2;

interface Polygon{
    public static final int a =20;
    void getName();
    void getArea();
}

interface Hexagon extends Polygon{
    //void getData();
}

class Rectangle implements Hexagon{
    public void getName(){
        System.out.println("Rectangle");
    }

    public void getArea(){
        System.out.println("Rectangle "+a);
    }

}

//class Square extends Rectangle implements Polygon, Hexagon{
//
//}
public class Interfacedemo {
    public static void main(String args[]){
        Rectangle rectangle = new Rectangle();
        rectangle.getName();
        rectangle.getArea();
    }
}
