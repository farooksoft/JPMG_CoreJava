package com.day2;

class Aa{
    Aa(){
        System.out.println("Iam from Aa");
    }
}
class Bb extends Aa{
    Bb(){
        System.out.println("Iam from Bb");
    }
}
class Cc extends Aa{
    Cc(){
        System.out.println("Iam from Cc");
    }
}

class Dd extends Bb{
    Dd(){
        System.out.println("Iam from Dd");
    }
}
public class HybridInheritanceDemo {
    public static void main(String args[]){
        Bb bb = new Bb();
        Cc cc = new Cc();
        Dd dd = new Dd();
    }
}
