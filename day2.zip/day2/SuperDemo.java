package com.day2;
class Parent{
    protected String name;
    public void details(){
        name = "Parent from the Parent class";
        System.out.println(name);
    }
}
public class SuperDemo extends Parent{
    String name;
    public void details(){
        super.name = "Parent";//refers to the parent class member
        name = "child";
        System.out.println(super.name + " and " + name);
        super.details(); // calling parent class details() method
    }

    public static void main(String args[]){
        SuperDemo superDemo = new SuperDemo();
        superDemo.details(); // called from child not the parent
    }
}
//    Parent and child
//        Parent from the Parent class
