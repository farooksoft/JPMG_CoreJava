package com.day2;
  class Display{
    // private Display(){}
    void show(){
        System.out.println("hello");
    }
}
public class FinalClassDemo extends Display{
    public static void main(String args[]){
        Display display = new Display();
        display.show();
    }
}
