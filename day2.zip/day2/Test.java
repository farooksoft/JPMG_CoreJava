package com.day2;

class Base{ //Parent class
    public void m1(){
        System.out.println("Base class method");
    }
}
class Derived extends Base{ //child Class extending the parent class
    public void m2(){
        System.out.println("Derived class method");
    }
}
public class Test {
    public static void main(String args[]){
        Derived derived = new Derived();
        derived.m1();
        derived.m2();
    }
}
