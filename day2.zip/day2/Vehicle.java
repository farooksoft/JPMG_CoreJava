package com.day2;

public class Vehicle {
    final int speedLimit = 60;
    void speedControl(){
        //speedLimit = 120;
    }

}
