package com.day8.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateData {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Connecting to the DB");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root", "root");
        Statement statement = connection.createStatement();

        String sql = "UPDATE EMPLOYEE SET NAME ='HARRY POTTER' WHERE ID = 102";

        statement.executeUpdate(sql);
        System.out.println("Transaction successful");
        connection.close();
    }

}
