package com.day8.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CreateTable {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the ID: " );
        String id = scanner.next();
        System.out.println("Enter the name: " );
        String name = scanner.next();
        System.out.println("Enter the age: " );
        String age = scanner.next();
        System.out.println("Enter the City: " );
        String city = scanner.next();
        System.out.println("Enter the Salary: " );
        String salary = scanner.next();

        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Connecting to the DB");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root", "root");
        Statement statement = connection.createStatement();
        /*String sql = "CREATE TABLE EMPLOYEE(ID INT NOT NULL AUTO_INCREMENT, NAME VARCHAR(20), AGE INT NOT NULL, ADDRESS CHAR(25),\n"+
                " SALARY DECIMAL(18,2), PRIMARY KEY (ID));";*/
        //String sql = "INSERT INTO EMPLOYEE VALUES(101, 'OSWALD', 32, 'DELHI',230000);";
        String sql = "INSERT INTO EMPLOYEE VALUES("+id+",'"+name+"', "+age+", '"+city+"',"+salary+");";

        int result = statement.executeUpdate(sql);
        if(result == 1 )
            System.out.println("Transaction successful"+sql);
        else
            System.out.println("Transaction Failed");

        connection.close();
    }
}
