package com.day8.jdbc;

import java.sql.*;

public class SelectData {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Connecting to the DB");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root", "root");
        Statement statement = connection.createStatement();

        //String sql = "DELETE FROM EMPLOYEE where id = 102";
        String sql = "DROP TABLE EMPLOYEE";
        //ResultSet rs = statement.executeQuery(sql);
//        while(rs.next()){
//            System.out.println("Employee Data");
//            System.out.println("ID"+ rs.getString(1));
//            System.out.println("Name "+ rs.getString(2));
//            System.out.println("Salary "+rs.getString(5));
//        }
        statement.executeUpdate(sql);
        System.out.println("Transaction successful");
        connection.close();
    }

}
