package com.day8.dateTime;

import java.util.Date;

public class DateDemo {
    public static void main(String[] args) {
        Date date = new Date();

        System.out.println("Current date: "+date);
    }
}
