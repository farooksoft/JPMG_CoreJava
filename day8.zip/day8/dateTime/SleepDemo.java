package com.day8.dateTime;

import java.util.Date;

public class SleepDemo {
    public static void main(String[] args) {
        try{
            System.out.println("Before Sleeping");;
            System.out.println(new Date());
            //sleeping 5 sec
            Thread.sleep(5000);
            System.out.println("after 5 sec");
            System.out.println(new Date());
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
