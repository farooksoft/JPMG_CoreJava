package com.day8.dateTime;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarDemo {
    public static void main(String[] args) {
        Calendar calendar = Calendar.getInstance();
        System.out.println("Current Date and Time: "+ calendar.getTime());

        //getting current date and time using date class
        System.out.println("Simple date time format");

        DateFormat dateFormat = new SimpleDateFormat("dd/MMM/YYYY HH:mm:ss");
        Date date = new Date();
        System.out.println(dateFormat.format(date));

        //getting current date and time using calendar class
        System.out.println("\n Using Calendar class");
        System.out.println("The formatted date and time is: ");
        Calendar calendar1 = Calendar.getInstance();
        System.out.println(dateFormat.format(calendar1.getTime()));

    }

}
