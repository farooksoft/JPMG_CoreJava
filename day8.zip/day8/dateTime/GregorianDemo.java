package com.day8.dateTime;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class GregorianDemo {
    public static void main(String[] args) {
        String months[] = {
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
        };

        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        //display the current date and time
        System.out.println("Today is:" +months[gregorianCalendar.get(Calendar.MONTH)]);
        System.out.println("Today is:" +gregorianCalendar.get(Calendar.DATE));
        int year = gregorianCalendar.get(Calendar.YEAR);
        System.out.println("Year is:" +year );
        System.out.println("Current Time: ");
        System.out.println(gregorianCalendar.get(Calendar.HOUR));
        System.out.println(gregorianCalendar.get(Calendar.MINUTE));
        System.out.println(gregorianCalendar.get(Calendar.SECOND));
        System.out.println(gregorianCalendar.get(Calendar.MILLISECOND));

        if(gregorianCalendar.isLeapYear(year)){
            System.out.println("The year is leap year");
        }else{
            System.out.println("This isn't a leap year");
        }
    }
}
