package com.day8.dateTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateStringDemo {
    public static void main(String[] args) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYY-MM-dd");
        String input ="2021-07-04";

        System.out.println("Input String is: "+input);

        Date date;
        try {
            date = simpleDateFormat.parse(input);
            System.out.println("Parsed String is:" + date);
        }catch (ParseException pe){
            System.out.println(pe.getMessage());
        }
    }
}
