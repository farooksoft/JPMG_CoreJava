package com.day8.fileIO;

import java.io.FileOutputStream;
import java.util.Scanner;

public class Filedemo1 {
    public static void main(String[] args) {
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the file name and specified path");
            String name = sc.nextLine();
            FileOutputStream fos = new FileOutputStream(name,true);

            System.out.println("Enter file content");
            String str = sc.nextLine() + "\n";

            byte[] b = str.getBytes();//converts the string into bytes
            fos.write(b); //writes the bytes to the file
            fos.close();
            System.out.println("The file has been saved on the given path");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
