package com.day8.fileIO;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {
    public static void main(String[] args) {
        try{
            File file = new File("D:\\FileDemo.txt");

            BufferedReader br = new BufferedReader(new FileReader(file));
            System.out.println("The file content is: ");
            int r = 0;
            while ((r=br.read())!= -1){
                System.out.println((char) r);
            }
        }catch (IOException e){
            System.out.println(e);
        }
    }
}
