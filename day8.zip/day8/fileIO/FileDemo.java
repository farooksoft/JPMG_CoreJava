package com.day8.fileIO;

import java.io.File;
import java.io.IOException;

public class FileDemo {
    public static void main(String[] args) {
        try{
            File file = new File("D:\\jpmg.txt");

            boolean flag= file.createNewFile();
            if(flag){
                System.out.println("file created successfully");
            }else{
                System.out.println("File already exist");
            }
        }catch (IOException e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
