package com.day8.fileIO;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class NIODemo {
    public static void main(String[] args) {
        Path path = Paths.get("D:\\Filetext.txt");
        try {
            Path p = Files.createFile(path);
            System.out.println("File create");
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
