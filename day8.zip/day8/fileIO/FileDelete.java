package com.day8.fileIO;

import java.io.File;

public class FileDelete {
    public static void main(String[] args) {
        try{
            File file = new File("D:\\FileDemo.txt");
            if(file.delete()){
                System.out.println("File"+ file.getName()+ "is deleted");
            }else{
                System.out.println("Operation Failed");
            }

            File file1 = new File("D:\\files.txt");
            file1.deleteOnExit();
            System.out.println("File" + file1.getName()+ "deleted");
            Thread.sleep(1000);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
