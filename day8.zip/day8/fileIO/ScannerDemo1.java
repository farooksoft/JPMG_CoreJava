package com.day8.fileIO;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class ScannerDemo1 {
    public static void main(String[] args) throws FileNotFoundException {

            File file = new File("D:\\FileDemo.txt");
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()){
                System.out.println(scanner.nextLine());
            }

        System.out.println("Employee Management system");
            Scanner scanner1 = new Scanner(System.in);
        System.out.println("enter the name: ");
            String name = scanner1.nextLine();
        System.out.println("Enter the city: ");
            String city = scanner1.nextLine();
        System.out.println("Enter the age: ");
            int age = scanner1.nextInt();

        System.out.println("Employee Details:");
        System.out.println("Hi, i'm "+ name + " from " + city + " and i'm " + age + " old.");



    }
}
