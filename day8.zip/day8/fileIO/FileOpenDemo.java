package com.day8.fileIO;

import java.io.FileInputStream;

public class FileOpenDemo {
    public static void main(String[] args) {
        try{
            FileInputStream fileInputStream = new FileInputStream("D:\\FileDemo.txt");

            int value = 0;
            while((value = fileInputStream.read()) != -1){
                System.out.println((char) value);
            }
            fileInputStream.close();
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
