package com.jpmg.day4.exceptionHandling;

public class UncaughtException {
    public static void main(String[] args) {
        try {
            System.out.println("Exception");
            int a = 0;
            System.out.println(a);
            int b = 8 / a;
            System.out.println(b);
        }catch (ArithmeticException e){
            System.out.println(e);
        }
        System.out.println("uncaught Exception demo");
    }
}
