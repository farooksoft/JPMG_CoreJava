package com.jpmg.day4.exceptionHandling;

public class FinallyDemo {
    public static void main(String[] args) {
        int a[] = new int[2];
        System.out.println("out of try");
        try{
            System.out.println("Access invalid element:" + a[3]);
        }catch (NullPointerException e){
            System.out.println(e);
        }
         finally {
            System.out.println("Finally is executed");
        }
        System.out.println("Exception handled");

    }
}
