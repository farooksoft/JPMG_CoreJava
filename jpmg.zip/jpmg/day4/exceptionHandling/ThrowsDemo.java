package com.jpmg.day4.exceptionHandling;

public class ThrowsDemo {
    static void check()throws ArithmeticException,ArrayIndexOutOfBoundsException,NullPointerException{
        System.out.println("Inside the check method");
        throw new ArithmeticException("demo");
    }

    public static void main(String[] args) throws ArithmeticException,ArrayIndexOutOfBoundsException {
        try{
            check();
        }catch (ArithmeticException e){
            System.out.println("CAUGHT:" + e);
        }
    }
}
