package com.jpmg.day4.exceptionHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TryWithoutResource {
    public static void main(String[] args) {
        try{
            String str;
            BufferedReader bufferedReader = new BufferedReader(new FileReader("D:\\demoFile.txt"));
            while ((str=bufferedReader.readLine())!=null){
                System.out.println(str);
            }
            bufferedReader.close();//buffered reader stream
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
