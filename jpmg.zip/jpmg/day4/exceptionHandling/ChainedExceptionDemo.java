package com.jpmg.day4.exceptionHandling;

import java.io.IOException;

public class ChainedExceptionDemo {
    public static void divide(int a, int b){
        if(b==0){
            ArithmeticException arithmeticException = new ArithmeticException("top Layer");
            arithmeticException.initCause(new IOException("cause"));
            throw arithmeticException;
        }
        else{
            System.out.println(a/b);
        }
    }

    public static void main(String[] args) {
        try{
            divide(5,0);
        }catch (ArithmeticException e){
            System.out.println("caught: " +e);
            System.out.println("Actual Cause: "+e.getCause());
        }
    }
}
