package com.jpmg.day4.exceptionHandling;

public class ExceptionPropagation {
    void a1(){
        int data = 30/0;
    }
    void a2(){
        a1();
    }
    void a3(){
        try{
            a2();
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        ExceptionPropagation exceptionPropagation = new ExceptionPropagation();
        exceptionPropagation.a3();
    }
}
