package com.jpmg.day4.exceptionHandling;

class MyExceptionDemo extends Exception{
    private int ex;
    MyExceptionDemo(int a){
        ex =a;
    }
    public String toString(){
        return "MyException[" +ex + "] is less than zero";
    }
}

class MyException{
    static void sum(int a, int b) throws MyExceptionDemo{
        if(a<0){
            throw new MyExceptionDemo(a);
        }
        else{
            System.out.println(a+b);
        }
    }

    public static void main(String[] args) {
        try{
            sum(-10,10);
        }catch (MyExceptionDemo e){
            System.out.println(e);;
        }
    }

}
