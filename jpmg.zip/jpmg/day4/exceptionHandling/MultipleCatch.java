package com.jpmg.day4.exceptionHandling;

public class MultipleCatch {
    public static void main(String[] args) {
        try {
            Integer in = new Integer("abc");
            in.intValue();
        }catch (ArithmeticException e){
            System.out.println("Arithmetic Exception:"+e);
        }catch (NumberFormatException e) {
            System.out.println("Number format Exception:" + e);
        }catch (Exception e){
            System.out.println("Exception Class: " +e);
        }
        System.out.println("Multiple Catch");
    }
}
