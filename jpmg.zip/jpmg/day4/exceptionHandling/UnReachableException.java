package com.jpmg.day4.exceptionHandling;

public class UnReachableException {
    public static void main(String[] args) {
        try{
            int arr[] = {1,2};
            arr[2] = 3/0;
        }catch (NumberFormatException e){
            System.out.println("Number format Exception:"+e);
        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Array Index: "+e);
        }catch (Exception e){
            System.out.println("Generic Exception: "+ e);
        }
        System.out.println("Unreachable Catch block");
    }
}
