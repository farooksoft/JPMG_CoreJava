package com.jpmg.day4.demo;

import com.jpmg.day4.implementation.Employee;

public class Main {
    public static void main(String[] args) {
        Student student = new Student();
        student.rollNo=1234;
        student.name="Henry";
        student.data();

        Employee employee = new Employee();
        employee.empID = 7098;
        employee.empName = "Oswald";
        employee.display();
        System.out.println(employee.empID + " " + employee.empName);
    }
}
