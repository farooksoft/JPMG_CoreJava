package com.jpmg.day4.demo;

public class Student {
    int rollNo;
    String name;

    public void data(){
        System.out.println("My Name is "+name+ "\n My Roll no is "+rollNo);
    }
}
