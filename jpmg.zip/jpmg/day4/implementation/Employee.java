package com.jpmg.day4.implementation;

public class Employee {
    public String empName;
    public int empID;
    private int age = 32;
    protected int salary = 456789;

    public void display(){
        System.out.println("Age: "+age +" Salary: "+salary);
    }

}
