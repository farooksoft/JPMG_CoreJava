package com.jpmg.day4.implementation;

public class WrapperClassMethods {
    public static void main(String[] args) {
        Integer intObj1 = new Integer(25);
        Integer intObj2 = new Integer("25");
        Integer intObj3 = new Integer(35);

        //compareTo
        System.out.println("intObj1 & intObj2: "+ intObj1.compareTo(intObj2));
        System.out.println("intObj1 & intObj3: "+intObj1.compareTo(intObj3));

        //equals
        System.out.println("intObj1 & intObj2: "+ intObj1.equals(intObj2));
        System.out.println("intObj1 & intObj3: "+intObj1.equals(intObj3));
    }
}
