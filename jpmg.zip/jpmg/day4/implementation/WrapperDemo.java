package com.jpmg.day4.implementation;

public class WrapperDemo {
    public static void main(String[] args) {
        //Wrapper Class
        Integer myInt = 10;
        Double myDouble = 11.66;
        Character myChar = 'T';
        Boolean myBool = true;

        //primitive Datatype
        int x = 20;
        double y = 30.90;
        char z = 'Z';
        boolean b = false;

        System.out.println(myInt +" "+ myDouble +" "+ myChar +" " + myBool);

        System.out.println(x +" "+ y+" "+z+" "+b);
    }


}
