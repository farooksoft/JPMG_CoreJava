package com.jpmg.day4.implementation;

public class ConversionMain {
    public static void main(String[] args) {
        Conversion conversion = new Conversion();
        conversion.method(10);
        conversion.method(new Integer(15));
        conversion.method(new Long(100));

    }
}
