package com.jpmg.day4.implementation;

import java.util.ArrayList;

public class AutoBoxingDemo {
    public static void main(String[] args) {
        // converting an int primitive data type into an Integer object
        int number = 20;
        Integer integer = Integer.valueOf(number);//Converting int to Integer Explicitly
        System.out.println(number + " "+ integer);

        // converting char primitive data type into an Character object

        char c = 'a';
        Character character = c;
        System.out.println(c + " "+ character);

        //Using Collection Framework

        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(16);// Autoboxing
        arrayList.add(49);
        System.out.println(arrayList.get(0) + " "+ arrayList.get(1));

    }
}
