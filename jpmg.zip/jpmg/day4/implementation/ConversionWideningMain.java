package com.jpmg.day4.implementation;

public class ConversionWideningMain {
    public static void main(String[] args) {
        ConversionWidening conversionWidening = new ConversionWidening();
        conversionWidening.method(10);
        conversionWidening.method(new Long(100));
    }
}
