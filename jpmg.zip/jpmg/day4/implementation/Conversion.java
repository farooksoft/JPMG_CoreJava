package com.jpmg.day4.implementation;

public class Conversion {
    //1. overloaded meth with primitive formal arg
    public void method(int i){
        System.out.println("Primitive type int formal arg:" + i);
    }
    //overloaded meth with ref formal arg
    public void method(Integer i){
        System.out.println("Reference type integer formal arg:" + i);
    }

    public void method(long i){
        System.out.println("Primitive type long formal arg:" + i);
    }
}
