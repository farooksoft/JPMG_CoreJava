package com.jpmg.day4.implementation;

public class ConversionWidening {
    public void method(int i){
        System.out.println("Primitive type int formal arg:" + i);
    }

    public void method(float i){
        System.out.println("Primitive type float formal arg:" + i);
    }
}
