package com.jpmg.day4.implementation;

public class WrapperClass {
    public static void main(String[] args) {
        //byte data type
        byte byteVar = 5;
        Byte byteObj = new Byte(byteVar); //wrapping around byte obj

        //int data type
        int intVar = 10;
        Integer intObj = new Integer(intVar);//wrapping around Integer obj

        //float data type
        float floatVar = 16.8f;
        Float floatObj = new Float(floatVar);//wrapping around Float obj

        double doubleVar = 456.97;
        Double doubleObj = new Double(doubleVar);

        char charVar = 's';
        Character charObj = charVar;

        //printing the values from obj
        System.out.println("Values of Wrapper Objects");
        System.out.println("Byte obj "+ byteObj);
        System.out.println("Integer obj " +intObj);
        System.out.println("Float obj " +floatObj);
        System.out.println("Double obj " + doubleObj);
        System.out.println("Char obj " + charObj);

        //unWrapping objects to primitive data type
        byte unwrapByte = byteObj;
        int unwrapInt = intObj;
        float unWrapFloat = floatObj;
        double unWrapDouble = doubleObj;
        char unWrapChar = charObj;

        System.out.println("UnWrapped Values");
        System.out.println(unwrapByte);
        System.out.println(unwrapInt);
        System.out.println(unWrapFloat);
        System.out.println(unWrapDouble);
        System.out.println(unWrapChar);

    }
}
