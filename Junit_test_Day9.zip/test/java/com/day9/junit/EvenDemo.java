package com.day9.junit;

import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertTrue;

public class EvenDemo {
    public boolean isEvenNumber(int number){
        boolean result = false;
        if(number%2 == 0){
            result = true;
        }
        return result;
    }
    @Test
    public void evenNumberTest(){
        EvenDemo evenDemo = new EvenDemo();
        assertTrue(evenDemo.isEvenNumber(4));
    }
}
