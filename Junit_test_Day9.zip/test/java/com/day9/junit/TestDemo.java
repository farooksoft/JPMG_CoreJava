package com.day9.junit;

import org.junit.jupiter.api.*;

public class TestDemo {
    @BeforeAll
    static void beforeAll(){
        System.out.println(" **Executed once before all the test methods in the class **");
    }

    @BeforeEach
    void beforeEach(){
        System.out.println("** Executed before each test method in the class **");
    }

    @Test
    void testMethod1(){
        System.out.println("**test method 1 executed **");
    }

    @Test
    @DisplayName("Test mtd 2")
    void testMethod2(){
        System.out.println("**test method 2 executed **");
    }

    @Test
    @Disabled("implementation pending")
    void testMethod3(){
        System.out.println("**test method 3 executed **");
    }

    @AfterEach
    void afterEach(){
        System.out.println("** Executed after each test method in the class **");
    }

    @AfterAll
    static void afterAll(){
        System.out.println(" **Executed once after all the test methods in the class **");
    }
}
