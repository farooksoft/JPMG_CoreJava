package com.day9.junit;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collection;

public class DynamicTestdemo {
    @TestFactory
    Iterable<DynamicTest> dynamicTestIterable(){
        return  Arrays.asList(
          DynamicTest.dynamicTest("Add test",
                  ()-> assertEquals(2, Math.addExact(1,1))),
                DynamicTest.dynamicTest("Multiply test",
                        ()-> assertEquals(4, Math.multiplyExact(2,2)))
        );
    }
}
class MyExecutable implements Executable{

    @Override
    public void execute() throws Throwable {
        System.out.println("hello world");
    }
}
