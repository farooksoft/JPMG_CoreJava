package com.day9.junit;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;
public class AssumptionDemo {

    @Test
    void testAssumeTrue(){
        boolean b= 'A' == 'A';
        assumeTrue(b);
        assertEquals("Hello", "Hello");
    }

    @Test
    void testAssumeTrueSaturday(){
        LocalDateTime dt = LocalDateTime.now();
        assumeTrue(dt.getDayOfWeek().getValue() == 2);
        System.out.println("Further code will execute only if this assumption is correct");
    }

    @Test
    void testAssumeFalse(){
        boolean b = 'A' != 'A';
        assumeFalse(b);
        assertEquals("Hello", "Hello");
    }

    @Test
    void testAssumeFalseEnvProp(){
        System.setProperty("env", "prod");
        assumeFalse("dev". equals(System.getProperty("env")));
        System.out.println("further code will execute only if above assumption hold");
    }

    @Test
    void testAssumingThat(){
        System.setProperty("env", "test");
        assumingThat("test".equals(System.getProperty("env")),
                ()-> {
            assertEquals(10, 10);
                    System.out.println("perform below assertions only on the test env");
                });
        assertEquals(20,20);
        System.out.println("perform below assertions on all env");
    }

}
