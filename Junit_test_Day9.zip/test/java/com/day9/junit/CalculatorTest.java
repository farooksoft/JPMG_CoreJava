package com.day9.junit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    @Test
    @DisplayName("Addition Test")
    void add() {
        assertEquals(5,Calculator.add(3,2));
    }

    @Test
    void multiply() {
        assertAll(
                ()->assertEquals(4, Calculator.multiply(2,2)),
                ()-> assertEquals(4, Calculator.multiply(-2,-2)),
                ()-> assertEquals(-4, Calculator.multiply(-2,2)),
                ()->assertEquals(0, Calculator.multiply(1,2))
        );
    }
}