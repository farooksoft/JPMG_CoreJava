package com.day9.j11features;

public interface Cal {
    int sum(int a, int b);
}
