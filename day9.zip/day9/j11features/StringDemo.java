package com.day9.j11features;

import java.util.stream.Stream;

public class StringDemo {
    public static void main(String[] args) {
        String str = "      The Quick Brow fox Jumps over a lazy dog.        ";
        //repeat
        System.out.println("Original string: "+str);
        String str1 = str.repeat(3);
        System.out.println(str1);
        str = "MAC";
        System.out.println(str);
        str1 = str.repeat(5);
        System.out.println(str1);


//        //strip()
//        System.out.println("Original String: " +str);
//        String str2 = str.strip();
//        System.out.println("Stripped String: "+str2);
//
//        //stripLeading()
//       String str3 = str.stripLeading();
//        System.out.println("Strip Leading: "+str3);
//
//        //stripTrailing()
//        System.out.println(str.length());
//        String str4 = str.stripTrailing();
//        System.out.println("Strip Trailing: "+str4);
//        System.out.println(str4.length());


//        //isBlank()
//        boolean r = str.isBlank();
//
//        System.out.println("First Check:" +r);
//
//        str = " ";
//        r = str.isBlank();
//        System.out.println("Second Check:" +r);

        //lines()

//        Stream<String> lines = str.lines();
//        lines.forEach(System.out::println);
    }
}
