package com.day9.j11features;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileDemo {
    public static void main(String[] args) {
        try{
            Path path = Paths.get("D:\\Filetext.txt");
            path = Files.writeString(path, "Welcome to Java 11 Features session!!!", Charset.forName("UTF-8"));
            String data = Files.readString(path);
            System.out.println("The Data: "+data);

        }catch (IOException e){
            System.out.println(e.getMessage());
        }


//        try {
//            //public static String readString(Path path) throws IOException
//            Path path = Paths.get("D:\\ErrorLog.txt");
//            String data = Files.readString(path);
//            System.out.println(data);
//            System.out.println("Details: "+data.getClass().getName());
//        }catch(IOException e){
//            System.out.println(e.getMessage());
//        }
    }
}
