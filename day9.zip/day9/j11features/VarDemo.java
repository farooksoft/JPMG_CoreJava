package com.day9.j11features;

class VarDemo {
    public static void main(String[] args) {
        Cal cal = (var a, var b) -> a+b;
        int result = cal.sum(10, 40);
        System.out.println(result);

        //
    }
}
