package com.day9.j11features;

public class NestDemo {
    private void display(){
        System.out.println("Hello from Private method");
    }

    class NestedMain{
        void msg(){
            display();
        }
    }
    public static void main(String[] args) {
        NestDemo nestDemo = new NestDemo();
        NestDemo.NestedMain nestedMain = nestDemo.new NestedMain();
        nestedMain.msg();
    }
}
