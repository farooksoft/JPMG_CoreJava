package com.day6;

import java.util.Scanner;

public class Student implements Cloneable{
    int age;
    String name;

    public Student(int age, String name) {
        this.age = age;
        this.name = name;
    }

    public void display(){
        System.out.println("Student Name: " +name);
        System.out.println("Student age: " +age);
    }

    public static void main(String[] args) throws CloneNotSupportedException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name: ");
        String name = sc.next();
        System.out.println("Enter your age: ");
        int age = sc.nextInt();
        Student student = new Student(age, name);
        Student student1 = (Student) student.clone();
        student1.display();

    }
}
