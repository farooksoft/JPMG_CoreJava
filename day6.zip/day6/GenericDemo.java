package com.day6;

public class GenericDemo {
    public static void main(String[] args) {
        MyGenClass<Integer> myObj = new MyGenClass<>();
        myObj.add(18);
       // myObj.add("Hello World");
        System.out.println(myObj.getObj());

        MyGenClass<String> myObj2 = new MyGenClass<>();
        myObj2.add("Hello World");
        System.out.println(myObj2.getObj());


    }
}
