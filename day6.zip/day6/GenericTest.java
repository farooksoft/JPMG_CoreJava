package com.day6;

public class GenericTest {
    //generic method
    public<T> void showItemDetails(T item){
        System.out.println("Value of the item: "+item);
        System.out.println("Type of the item: "+ item.getClass().getName());
    }
}

class MainTest{
    public static void main(String[] args) {
        GenericTest test = new GenericTest();
        test.showItemDetails("Test String");
        test.showItemDetails(1000);
        test.showItemDetails(435.908);
        test.showItemDetails('C');
    }
}
