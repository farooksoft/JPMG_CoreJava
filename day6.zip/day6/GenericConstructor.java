package com.day6;

public class GenericConstructor {
//    public <T> GenericConstructor(T item){
//        System.out.println("value of the item: "+ item);
//        System.out.println("Type of the Item: "+item.getClass().getName());
//    }
    public <T, U> GenericConstructor(T itemT, U itemU){
        System.out.println("value of the item: "+ itemT);
        System.out.println("Type of the Item: "+itemT.getClass().getName());

        System.out.println("value of the item: "+ itemU);
        System.out.println("Type of the Item: "+itemU.getClass().getName());
    }
}

class MainGenerics{
    public static void main(String[] args) {
        GenericConstructor genericConstructor = new GenericConstructor("Test String", 12345);
        GenericConstructor genericConstructor1 = new GenericConstructor(1023, 2345.678);
    }
}
