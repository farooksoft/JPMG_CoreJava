package com.day6;

public class GenericMethodDemo {
    public static<Z> void printArray(Z[] inputArray){
        for (Z element: inputArray){
            System.out.println(element);
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Integer[] intArrays = {10, 20, 30, 40 , 50};
        printArray(intArrays);

        Double[] intDouble = {1.2, 1.3, 1.5, 1.6};
        printArray(intDouble);


    }
}
