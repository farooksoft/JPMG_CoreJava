package com.day6;

public class MyGenClass<T> {
    T obj;
    void add(T obj){
        this.obj = obj;
    }

    T getObj(){
        return obj;
    }
}
