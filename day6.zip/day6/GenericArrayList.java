package com.day6;

import java.util.ArrayList;

public class GenericArrayList {
    public static void main(String[] args) {
        ArrayList<String> al = new ArrayList();
        al.add("Henry");
        al.add("Harry");
        //al.add(10);

        String s1 = (String) al.get(0);
        String s2 = (String) al.get(1);

        try{
            String s3 = (String) al.get(2);
        }catch (Exception e){
            System.out.println(e);
        }

    }
}
