package com.day6;

public class Generics<T, U> {
    T obj1;
    U obj2;

    //constructors
    public Generics(T obj1, U obj2) {
        this.obj1 = obj1;
        this.obj2 = obj2;
    }

    //to print objects of T & U
    public void getObjects(){
        System.out.println("String value: " +obj1);
        System.out.println("Integer Value: "+obj2);
    }
}

class Main{
    public static void main(String[] args) {
        Generics<String, Integer> obj = new Generics<>("Hello World", 17);
        obj.getObjects();

        Generics<Integer, Double> obj2 = new Generics<>(176, 98.98);
        obj2.getObjects();
    }
}
