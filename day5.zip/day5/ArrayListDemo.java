package com.day5;

import java.util.ArrayList;

public class ArrayListDemo {
    public static void main(String[] args) {
        //create an object pf the non generic arraylist
        ArrayList al = new ArrayList(); //capacity 10
        al.add("a");
        al.add("b");
        al.add(20);
        al.add("c");
        al.add("d");
        System.out.println(al);

        //creating another generic list

        ArrayList arrayList = new ArrayList();
        arrayList.add("Red");
        arrayList.add("a");
        arrayList.add("c");

        al.addAll(arrayList);
        System.out.println(al);

        arrayList.addAll(2,al);
        System.out.println(arrayList);

        arrayList.remove("a");
        System.out.println(arrayList);

        arrayList.set(4, null);
        System.out.println(arrayList);

        System.out.println(arrayList.size());

        System.out.println(arrayList.contains("z"));

    }
}
