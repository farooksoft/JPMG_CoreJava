package com.day5;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {
    public static void main(String[] args) {
        //Create a map of generic type
        Map<Integer, String> map = new HashMap<>();

        //checking if the map is empty
        boolean isEmpty = map.isEmpty();
        System.out.println("is map empty? "+isEmpty);

        //adding the entries
        map.put(101,"Red");
        map.put(102,"Purple");
        map.put(107,"Pink");
        map.put(103,"Black");
        map.put(106,"White");
        map.put(106,"Orange");

        System.out.println("Entries in the map: "+map);
        int size = map.size();
        System.out.println("Size : "+size);

        //Create another map
        Map<Integer,String> map1 = new HashMap<>();
        map1.put(112, "Brown");
        map1.put(114,"Green");
        map.putAll(map1);

        System.out.println(map);

        //replace the old data
        map.replace(112,"Brown", "Blue");
        map.replace(112,"blue");
        System.out.println(map);

        //Removing the entry from the specific key
        map.remove(102);
        System.out.println(map);

        //retrive the key
        Set<Integer> keys = map.keySet();
        System.out.println("set of keys: "+keys);

        Collection<String> values = map.values();
        System.out.println("Collection of Values: "+values);

        String data = map.get(103);
        System.out.println(data);

        map.clear();
        System.out.println(map);
    }
}
