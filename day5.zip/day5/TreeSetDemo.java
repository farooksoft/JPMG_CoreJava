package com.day5;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {
    public static void main(String[] args) {
        //create tree set
        Set<String> ts = new TreeSet<>();

        boolean empty = ts.isEmpty();
        System.out.println("is empty:"+empty);

        ts.add("USA");
        ts.add("India");
        ts.add("Aus");
        ts.add("New Zealand");

        System.out.println("Sorted Treeset: "+ts);
        System.out.println("Tree Set size: "+ ts.size());

        System.out.println(ts.contains("USA"));

        ts.remove("Aus");
        System.out.println(ts);

        Iterator<String> itr = ts.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }

        //itr in descending order
        Iterator<String> it = ((TreeSet<String>)ts).descendingIterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }

        ts.clear();
        System.out.println(ts);
    }
}
