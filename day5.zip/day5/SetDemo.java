package com.day5;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class SetDemo {
    public static void main(String[] args) {
        Set<String> s = new HashSet<>();
        int size = s.size();
        System.out.println("Size before adding the elements: " + size);

        //add the elements to set
        s.add("Orange");
        s.add("Apple");
        s.add("Grape");
        System.out.println(s);

        //Add the duplicate elements
        s.add("Apple");
        s.add("Grape");
        s.add("Peach");
        System.out.println(s);

        if(s.equals("Banana")){
            System.out.println("Present");
        }else{
            s.add("Banana");
            System.out.println("Transaction Successful: " + s);
        }

        Set<String> s2 = new LinkedHashSet<>();
        s2.add("White");
        s2.add("Purple");
        s2.add("Apple");
        System.out.println("New Set: "+s2);

        s.addAll(s2);
        System.out.println(s);
    }

}
