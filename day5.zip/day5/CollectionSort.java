package com.day5;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionSort {
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Harry");
        arrayList.add("Alice");
        arrayList.add("Della");
        arrayList.add("Pinto");

        System.out.println(arrayList);

        //Ascending order
        Collections.sort(arrayList);
        System.out.println(arrayList);

        //descending order
        Collections.sort(arrayList, Collections.reverseOrder());
        System.out.println(arrayList);

    }
}
