package com.day5;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {
    public static void main(String[] args) {
        //create a list
        List al = new ArrayList();

        al.add(10);
        al.add(30);
        al.add(20);
        al.add(70); //integer
        al.add("Harry");
        al.add(45.89); //float
        al.add("the quick brown fox");

        System.out.println("The Array List"+ al);

        al.add(4,100);
        System.out.println("The Array List"+ al);

        //create another list of String Type
        List<String> al2 = new ArrayList<>();
        al2.add("11");
        al2.add("13");
        al2.add("15");
        //al2.add(90);
        System.out.println("New Array List:"+al2);

        //adding List 2 at the 2nd position using addAll in list 1
        al.addAll(2,al2);
        System.out.println("The Array List"+ al);
        al.add(al2);
        System.out.println("The Array List"+ al);

        System.out.println(al.get(10));
        System.out.println(al.indexOf("20"));
        System.out.println(al.lastIndexOf(al2));

    }
}
