package com.day5;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {
    public static void main(String[] args) {
        //Creating tree map
        TreeMap<String, Integer> treeMap = new TreeMap<>();

        //add the element
        treeMap.put("A", 100);
        treeMap.put("B", 200);
        treeMap.put("C", 300);
        treeMap.put("D", 400);
        treeMap.put("E", 500);

        System.out.println(treeMap);

        System.out.println("first Element: "+treeMap.firstEntry());
        System.out.println("Last Element: "+treeMap.lastEntry());

        System.out.println("Head Map: "+treeMap.headMap("C"));
        System.out.println("Tail Map: "+treeMap.tailMap("C"));

        System.out.println("Iterator Demo");
        Set<Map.Entry<String, Integer>> st = treeMap.entrySet();
        for (Map.Entry<String, Integer> me:st){
            System.out.print(me.getKey()+ ":");
            System.out.println(me.getValue());
        }

        treeMap.remove("D");
        System.out.println("Removed D:" +treeMap);

        System.out.println(" Poll First Entry: " +treeMap.pollFirstEntry());
        System.out.println("Poll Last Entry: "+ treeMap.pollLastEntry());
    }
}
