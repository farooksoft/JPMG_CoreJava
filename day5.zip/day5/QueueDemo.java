package com.day5;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
    public static void main(String[] args) {
        //create a queue
        Queue<String> queue = new LinkedList<>();

        //Add the element
        queue.add("ABC");
        queue.add("DEF");
        queue.add("GHI");
        queue.add("JKL");

        System.out.println("Elements in the q: " +queue);
        System.out.println("Head Element: "+queue.element());
        System.out.println("Remove the element: "+ queue.remove());
        System.out.println("Altered q: "+queue);

        boolean addElement = queue.offer("PQR");
        System.out.println("Current elements: "+ queue);
        System.out.println(addElement);
        System.out.println(queue.peek());
        System.out.println(queue);
        System.out.println(queue.poll());
        System.out.println(queue);
    }
}
